﻿// fecha actual dinámicamente en el siguiente formato de fecha: lunes 6 de abril de 2020
